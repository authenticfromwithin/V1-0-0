import React from "react";

// This shim keeps your existing import path stable: "@/components/AuthPanel"
// It lazily resolves to the real component regardless of whether your project
// uses: src/components/AuthPanel.tsx, src/components/AuthPanel/index.tsx,
// or src/components/AuthPanel/AuthPanel.tsx. No redesign; purely wiring.
const RealAuthPanel = React.lazy(async () => {
  try {
    const m = await import("./AuthPanel/AuthPanel"); // common nested
    return { default: (m as any).default ?? (m as any).AuthPanel ?? (m as any) };
  } catch {}
  try {
    const m = await import("./AuthPanel/index"); // folder index
    return { default: (m as any).default ?? (m as any).AuthPanel ?? (m as any) };
  } catch {}
  try {
    const m = await import("./AuthPanel"); // flat file
    return { default: (m as any).default ?? (m as any).AuthPanel ?? (m as any) };
  } catch {}
  console.warn("[AFW] AuthPanel shim: real component not found; rendering null.");
  return { default: () => null };
});

export default function AuthPanel(props: any) {
  return (
    <React.Suspense fallback={null}>
      <RealAuthPanel {...props} />
    </React.Suspense>
  );
}
